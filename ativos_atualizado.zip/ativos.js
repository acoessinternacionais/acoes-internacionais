
async function buscarAtivos(periodo = '1d') {
    const tabela = document.querySelector('#ativos-table tbody');
    tabela.innerHTML = '';

    const tickers = ['AAPL', 'MSFT', 'GOOGL', ' 'AMZN', 'PETR4.SA', 'VALE3.SA'];
    const promises = tickers.map(async (ticker) => {
        try {
            const res = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?interval=1d&range=${periodo}`);
            const data = await res.json();
            const result = data.chart.result[0];

            const precoAtual = result.meta.regularMarketPrice;
            const precoAnterior = result.meta.chartPreviousClose;
            const variacao = precoAtual - precoAnterior;
            const percentual = ((variacao / precoAnterior) * 100).toFixed(4);

            const precoFormatado = precoAtual.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
            const direcao = variacao >= 0 ? 'arrow-up positive' : 'arrow-down negative';
            const variacaoFormatada = `<span class="${direcao}">${variacao.toFixed(2)} (${percentual}%)</span>`;

            const linha = `
                <tr>
                    <td>${ticker}</td>
                    <td>${ticker}</td>
                    <td>${precoFormatado}</td>
                    <td>--</td>
                    <td>${variacaoFormatada}</td>
                </tr>
            `;
            tabela.innerHTML += linha;
        } catch (error) {
            console.error('Erro ao buscar dados para', ticker, error);
        }
    });

    await Promise.all(promises);
}

document.addEventListener('DOMContentLoaded', () => {
    const seletor = document.getElementById('periodo');
    buscarAtivos(seletor.value);

    seletor.addEventListener('change', () => {
        buscarAtivos(seletor.value);
    });
});
